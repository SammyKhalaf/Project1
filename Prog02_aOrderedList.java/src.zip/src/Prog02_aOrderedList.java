import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;
import java.io.PrintWriter;
import java.util.ArrayList;
//**
// * This class initiates the variables make, year, and price as well as constructs those variables into methods.
// *
// * CSC 1351 Programming Project No 2
// *
// * 002
// *
// * Aiden Kirk
// * 10/23/23
//*
//*
 class Car implements Comparable<Car> {

    private String make;
    private int year;
    private int price;

    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
        //presents variables for car class
    }

    public String getMake() {
        return make;
        //constructor for make
    }

    public int getYear() {
        return year;
        //constructor for year
    }

    public int getPrice() {
        return price;
        //constructor for price
    }


    public int compareTo(Car other) {
        if (!this.make.equals(other.make)) {
            return this.make.compareTo(other.make);
        } else if (this.year != other.year) {
            return this.year - other.year;
        }
return 0;
    }
//comparable compares make then year

    public String toString() {
        return "Make: " + make + "\nYear: " + year + "\nPrice: $" + price;
    }
    //essentially a return info method that returns the info of each car with these parameters
}
//**
// * Class a orderered list initializes the variables oList, listsize (for arraylist), numObjects (for the number of cars in the list) and the current car as well as the size of the array need it be changed
// *
// * CSC 1351 Programming Project No 1
// *
// * 002
// *
// * Aiden Kirk
// * 10/23/23
//*
//*
class aOrderedList {
    private Comparable[] oList;
    private int listSize;
    private int numObjects;
    private int curr;

    public aOrderedList() {
        numObjects = 0;
        listSize = 20;  // Start with a reasonable initial size
        oList = new Comparable[listSize];
        curr = -1;
    }

    public void add(Comparable newObject) {
        if (numObjects == listSize) {
            resizeArray();
        }

        int index = 0;
        while (index < numObjects && newObject.compareTo(oList[index]) >= 0) {
            index++;
        }
        for (int i = numObjects; i > index; i--) {
            oList[i] = oList[i - 1];
        }
        oList[index] = newObject;
        numObjects++;
    }

    public int size() {
        return numObjects;
    }

    public Comparable get(int index) {
        return oList[index];
    }

    public boolean isEmpty() {
        return numObjects == 0;
    }

    public void remove() {
        if (curr >= 0 && curr < numObjects) {
            for (int i = curr; i < numObjects - 1; i++) {
                oList[i] = oList[i + 1];
            }
            oList[numObjects - 1] = null; // Set the last element to null
            numObjects--; // Decrease the count
            curr--; // Adjust the current position

        }
    }

    public void reset() {
        curr = -1;
    }

    public Comparable next() {
        if (curr < numObjects - 1) {
            curr++;
            return oList[curr];
        }
        return null;
    }

    public boolean hasNext() {
        return curr < numObjects - 1;
    }

    private void resizeArray() {
        listSize *= 2; // Double the size of the array
        Comparable[] newArray = new Comparable[listSize];
        System.arraycopy(oList, 0, newArray, 0, numObjects);
        oList = newArray;
    }


    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("Number of cars: " + numObjects + "\n");
        for (int i = 0; i < numObjects; i++) {
            result.append(oList[i].toString()).append("\n");
        }
        return result.toString();
    }
}


public class Prog02_aOrderedList {
    public static void main(String[] args) {
        Scanner inputScanner = GetInputFile("Enter the input filename");
        aOrderedList carList = new aOrderedList();

        while (inputScanner.hasNextLine()) {
            String line = inputScanner.nextLine();
            String[] parts = line.split(",");
            if (parts.length >= 4) {
                String operation = parts[0];
                if (operation.equals("A")) {
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = Integer.parseInt(parts[3]);
                    Car car = new Car(make, year, price);
                    carList.add(car);
                } else if (operation.equals("D")) {
                    // Handle delete operation based on make and year
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);

                    // Loop to find and delete the car
                    carList.reset();
                    while (carList.hasNext()) {
                        Car car = (Car) carList.next();
                        if (car.getMake().equals(make) && year == car.getYear()) {
                            carList.remove();
                            break; // Remove only one matching car
                        }
                    }
                }
            }
        }
        inputScanner.close();

        try {
            PrintWriter outputWriter = GetOutputFile("Enter the output filename");
            outputWriter.print(carList.toString());
            outputWriter.close();
            System.out.println("Data written to the output file.");
        } catch (FileNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public static Scanner GetInputFile(String UserPrompt) {
        Scanner scanner = null;
        boolean validInput = false;

        while (!validInput) {
            System.out.print(UserPrompt + ": ");
            Scanner userInput = new Scanner(System.in);
            String fileName = userInput.nextLine();

            File file = new File(fileName);
            if (file.exists()) {
                try {
                    scanner = new Scanner(file);
                    validInput = true;
                } catch (FileNotFoundException e) {
                    System.out.println("Error opening the file: " + e.getMessage());
                }
            } else {
                System.out.println("File specified <" + fileName + "> does not exist. Would you like to continue? <Y/N> ");
                String continueResponse = userInput.nextLine();
                if (!continueResponse.equalsIgnoreCase("Y")) {
                    userInput.close();
                    System.exit(0);
                }
            }
        }
        return scanner;
    }

    public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
        PrintWriter printWriter = new PrintWriter("output.txt");
        boolean validOutput = false;

        while (!validOutput) {
            System.out.print(UserPrompt + ": ");
            Scanner userInput = new Scanner(System.in);
            String fileName = userInput.nextLine();

            File file = new File(fileName);
            try {
                printWriter = new PrintWriter(file);
                validOutput = true;
            } catch (FileNotFoundException e) {
                System.out.println("Error opening the file: " + e.getMessage());
                System.out.println("Would you like to continue? <Y/N> ");
                String continueResponse = userInput.nextLine();
                if (!continueResponse.equalsIgnoreCase("Y")) {
                    userInput.close();
                    throw e;
                }
            }
        }
        return printWriter;
    }
}
